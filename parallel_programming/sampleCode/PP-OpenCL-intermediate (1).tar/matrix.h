#define N 1024
#define Blk 64
#define BSIDE (N / Blk)
