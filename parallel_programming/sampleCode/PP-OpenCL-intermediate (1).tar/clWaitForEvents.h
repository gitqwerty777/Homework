cl_int clWaitForEvents(cl_uint num_events,
		       const cl_event *event_list);
