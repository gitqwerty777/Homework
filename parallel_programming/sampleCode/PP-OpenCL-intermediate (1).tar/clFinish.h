cl_int clFinish(cl_command_queue command_queue);
