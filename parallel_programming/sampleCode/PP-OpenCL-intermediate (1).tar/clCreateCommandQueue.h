cl_command_queue 
clCreateCommandQueue(cl_context context,
		     cl_device_id device,
		     cl_command_queue_properties 
		     properties,
		     cl_int *errcode_ret);
