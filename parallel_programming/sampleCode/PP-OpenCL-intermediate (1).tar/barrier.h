void barrier(cl_mem_fence_flags flags);
