size_t get_global_id(uint dimindx);
