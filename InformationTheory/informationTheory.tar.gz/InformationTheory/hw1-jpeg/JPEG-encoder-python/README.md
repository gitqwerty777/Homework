## 简易的灰度bmp和jpg转换

依赖矩阵库：numpy

使用方法

	python jpeg/main.py --src /tmp/image.bmp
	python jpeg/main.py --src /tmp/image.jpg
	
![](data/screenshot.png)