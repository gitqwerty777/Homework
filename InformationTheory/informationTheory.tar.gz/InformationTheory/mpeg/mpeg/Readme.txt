1. make
2. execute ./bin/main
3. have fun www
