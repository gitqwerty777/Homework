typedef unsigned char byte;
extern const char start_code[];
